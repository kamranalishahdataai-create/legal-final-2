import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
Deno.serve((req) => {
 if (req.method === "OPTIONS") return new Response("ok", {headers: corsHeaders});
 return new Response(JSON.stringify({error: "The client referral reward program has been retired. No draw entries or reward notifications are issued."}), {status: 410, headers: {...corsHeaders, "Content-Type":"application/json"}});
});
