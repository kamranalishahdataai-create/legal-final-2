import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ============ FREE LEGAL DATA SOURCES (Canada only) ============
// All sources below are free / no-API-key (or optional key) public legal databases.
//
// Canada:
//  - CanLII (requires free API key — gracefully skipped without one)
//  - Supreme Court of Canada (SCC) decisions — via Google CSE
//  - Federal Court of Canada decisions — via Google CSE
//  - Google Programmable Search (CSE) — general legal web results

// CanLII — Canadian Legal Information Institute (requires free API key)
async function searchCanLII(query: string, limit = 5) {
  try {
    const apiKey = Deno.env.get("CANLII_API_KEY");
    if (!apiKey) return []; // gracefully skip until key added
    const url = `https://api.canlii.org/v1/caseBrowse/en/?api_key=${apiKey}&resultCount=${limit}&search=${encodeURIComponent(query)}`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    return (data.cases || []).map((c: { title?: string; citation?: string; databaseId?: string; caseId?: { en?: string }; decisionDate?: string }) => ({
      name: c.title || "Unknown",
      citation: c.citation || "",
      court: c.databaseId || "",
      year: c.decisionDate ? c.decisionDate.slice(0, 4) : "",
      url: c.caseId?.en ? `https://www.canlii.org/en/${c.databaseId}/doc/${c.caseId.en}/` : "",
      snippet: "",
      source: "CanLII",
    }));
  } catch (e) {
    console.error("CanLII error:", e);
    return [];
  }
}

// Google Programmable Search (CSE) — optional, restricted to legal sites
async function searchGoogleCSE(query: string, limit = 5) {
  try {
    const key = Deno.env.get("GOOGLE_CSE_API_KEY");
    const cx = Deno.env.get("GOOGLE_CSE_ID");
    if (!key || !cx) return [];
    const url = `https://www.googleapis.com/customsearch/v1?key=${key}&cx=${cx}&q=${encodeURIComponent(query)}&num=${limit}`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    return (data.items || []).map((it: { title?: string; link?: string; snippet?: string; displayLink?: string }) => ({
      name: it.title || "",
      citation: "",
      court: it.displayLink || "",
      year: "",
      url: it.link || "",
      snippet: it.snippet || "",
      source: `Google (${it.displayLink || "web"})`,
    }));
  } catch (e) {
    console.error("Google CSE error:", e);
    return [];
  }
}

// Supreme Court of Canada decisions (scc-csc.lexum.com) — open, search via CSE
async function searchSCC(query: string, limit = 3) {
  return searchGoogleCSE(`site:scc-csc.lexum.com ${query}`, limit);
}

// Federal Court of Canada decisions (decisions.fct-cf.gc.ca) — open
async function searchFederalCourtCanada(query: string, limit = 3) {
  return searchGoogleCSE(`site:decisions.fct-cf.gc.ca ${query}`, limit);
}


const MODEL = "google/gemini-3-flash-preview";

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  try {
    const body = await req.json();
    const areaOfLaw = String(body.areaOfLaw || "").slice(0, 80);
    const jurisdiction = String(body.jurisdiction || "").slice(0, 40);
    const issues: string[] = Array.isArray(body.issues) ? body.issues.slice(0, 8).map((i: unknown) => String(i).slice(0, 60)) : [];
    const courtLevel = String(body.courtLevel || "any").slice(0, 20);
    const dateRange = String(body.dateRange || "any").slice(0, 10);
    const partyType = String(body.partyType || "any").slice(0, 30);
    // Keywords are used only for retrieval and are never stored or echoed back.
    const keywords = String(body.keywords || "").slice(0, 120);
    if (!areaOfLaw || !jurisdiction) return json({ error: "Missing required filters" }, 400);

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const searchQuery = [areaOfLaw, ...issues, keywords].filter(Boolean).join(" ");
    const [canlii, scc, fct, google] = await Promise.all([
      searchCanLII(searchQuery, 10),
      searchSCC(searchQuery, 5),
      searchFederalCourtCanada(searchQuery, 5),
      searchGoogleCSE(`${searchQuery} ${jurisdiction} decision`, 5),
    ]);
    // Only decisions resolved to a public source with a link may be shown.
    const sources = [...canlii, ...scc, ...fct, ...google].filter((p) => p.url);
    const filters = { areaOfLaw, issues, jurisdiction, courtLevel, dateRange, partyType };
    if (sources.length === 0) {
      return json({ decisions: [], factorsConsidered: [], questionsForLawyer: [], legalPrinciples: [], scopeLabel: "" });
    }

    const systemPrompt = `You are a case-law research assistant. You describe published decisions only.
Never estimate anyone's chances, never give a win rate or probability, never recommend a strategy, and never refer to the user's case or facts.
Use ONLY the numbered source decisions provided. For each one you can identify as a court or tribunal decision, return its index, a neutral summary, what the court decided, a similarity score (0-100) measuring how closely its text and issues match the search filters, and the outcome for the claimant/appellant as stated in the decision text: succeeded, did_not_succeed, settled, or mixed (use mixed whenever unclear).
Also list factors the courts considered (descriptive, from the decisions), legal principles stated in them, and neutral questions a person could raise with a lawyer.`;

    const userPrompt = `Search filters: ${JSON.stringify(filters)}
Sources:
${sources.map((p, i) => `[${i}] ${p.name} — ${p.citation} (${p.court} ${p.year}) ${p.url}\n${p.snippet}`).join("\n\n")}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: MODEL,
        messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userPrompt }],
        tools: [{
          type: "function",
          function: {
            name: "research_report",
            description: "Describe matched published decisions",
            parameters: {
              type: "object",
              properties: {
                decisions: { type: "array", items: { type: "object", properties: {
                  sourceIndex: { type: "number" },
                  outcome: { type: "string", enum: ["succeeded", "did_not_succeed", "settled", "mixed"] },
                  similarity: { type: "number" },
                  summary: { type: "string" },
                  conclusion: { type: "string" },
                }, required: ["sourceIndex", "outcome", "similarity", "summary", "conclusion"] } },
                factorsConsidered: { type: "array", items: { type: "object", properties: { factor: { type: "string" }, description: { type: "string" } }, required: ["factor", "description"] } },
                legalPrinciples: { type: "array", items: { type: "string" } },
                questionsForLawyer: { type: "array", items: { type: "string" } },
              },
              required: ["decisions", "factorsConsidered", "legalPrinciples", "questionsForLawyer"],
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "research_report" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) return json({ error: "Rate limit exceeded. Please try again in a few moments." }, 429);
      if (response.status === 402) return json({ error: "AI service requires additional credits. Please contact support." }, 402);
      console.error("AI gateway error:", response.status, await response.text());
      throw new Error("Research failed");
    }

    const data = await response.json();
    const args = data.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    if (!args) throw new Error("Invalid AI response format");
    const raw = JSON.parse(args);

    const seen = new Set<number>();
    const decisions = (raw.decisions || [])
      .filter((d: { sourceIndex: number }) => Number.isInteger(d.sourceIndex) && sources[d.sourceIndex] && !seen.has(d.sourceIndex) && seen.add(d.sourceIndex))
      .map((d: { sourceIndex: number; outcome: string; similarity: number; summary: string; conclusion: string }) => {
        const src = sources[d.sourceIndex];
        return {
          name: src.name, citation: src.citation, year: src.year, court: src.court, url: src.url, source: src.source,
          outcome: ["succeeded", "did_not_succeed", "settled", "mixed"].includes(d.outcome) ? d.outcome : "mixed",
          similarity: Math.max(0, Math.min(100, Math.round(d.similarity))),
          summary: d.summary, conclusion: d.conclusion,
        };
      })
      .sort((a: { similarity: number }, b: { similarity: number }) => b.similarity - a.similarity);

    const report = {
      decisions,
      factorsConsidered: raw.factorsConsidered || [],
      legalPrinciples: raw.legalPrinciples || [],
      questionsForLawyer: raw.questionsForLawyer || [],
      scopeLabel: "",
    };

    // Audit log: filters, model version, sources retrieved and output. Keywords are not stored.
    const authHeader = req.headers.get("Authorization");
    if (authHeader) {
      try {
        const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
        const { data: userData } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
        if (userData?.user) {
          await supabase.from("case_analyses").insert({
            user_id: userData.user.id,
            case_type: areaOfLaw,
            jurisdiction,
            case_description: "[not stored]",
            preview_result: { ...report, audit: { model: MODEL, filters, sources, generatedAt: new Date().toISOString() } },
          });
        }
      } catch (dbError) {
        console.error("Failed to log report:", dbError);
      }
    }

    return json(report);
  } catch (error) {
    console.error("analyze-case error:", error);
    return json({ error: error instanceof Error ? error.message : "Research failed" }, 500);
  }
});
