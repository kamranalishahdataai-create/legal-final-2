
CREATE OR REPLACE FUNCTION private.current_lawyer_id()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id FROM public.lawyers WHERE user_id = auth.uid() AND is_active = true LIMIT 1
$$;
GRANT USAGE ON SCHEMA private TO authenticated;
GRANT EXECUTE ON FUNCTION private.current_lawyer_id() TO authenticated;

CREATE POLICY "Lawyers view assigned consultations" ON public.consultations
  FOR SELECT TO authenticated USING (lawyer_id = private.current_lawyer_id());
CREATE POLICY "Lawyers update assigned consultations" ON public.consultations
  FOR UPDATE TO authenticated USING (lawyer_id = private.current_lawyer_id())
  WITH CHECK (lawyer_id = private.current_lawyer_id());

CREATE POLICY "Lawyers view their clients profiles" ON public.profiles
  FOR SELECT TO authenticated USING (EXISTS (
    SELECT 1 FROM public.consultations c
    WHERE c.user_id = profiles.user_id AND c.lawyer_id = private.current_lawyer_id()));

CREATE POLICY "Lawyers update their own assignments" ON public.lawyer_case_assignments
  FOR UPDATE TO authenticated USING (lawyer_id = private.current_lawyer_id())
  WITH CHECK (lawyer_id = private.current_lawyer_id());

CREATE POLICY "Lawyers update their own profile" ON public.lawyers
  FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- Auto-link a lawyer record to a new account with the same email
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'client');

  UPDATE public.lawyers SET user_id = NEW.id
  WHERE user_id IS NULL AND lower(email) = lower(NEW.email);
  IF FOUND THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'lawyer')
    ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;
