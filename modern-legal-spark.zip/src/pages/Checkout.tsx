import { PriceNotice, ProviderNotice } from "@/components/legal/PracticeNotice";
import { BILLING_SHORT, BILLING_NOTE } from "@/data/billingTerms";
import { PROFESSIONAL_REPORTS_PER_MONTH } from "@/data/caseResearch";
import { useState } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Check, CreditCard, Lock, ArrowLeft, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { LegalDisclaimer } from "@/components/legal/LegalDisclaimer";
import { useAuth } from "@/hooks/useAuth";

const plans = {
  contracts: {
    name: "Contract Library",
    price: "$4.99",
    period: "/mo",
    description: "Template subscription only — not a legal-service membership",
    features: [
      "Download any contract template",
      "Downloads subject to fair use",
      "Canadian templates; suitability differs by province and situation",
      "Month-to-month · cancel whenever",
    ],
  },
  personal: {
    name: "Personal Legal Protection",
    price: "$12.00",
    period: "/year",
    description: "Essential legal coverage for individuals",
    features: [
      "Case Law Research Tool access",
      "Contract library access",
      "Monthly legal newsletter",
    ],
  },
  "corporate-starter": {
    name: "Business Starter — Sole Proprietors",
    price: "$29.00",
    period: "/mo · 12-month term",
    description: "Starter business membership for freelancers and sole proprietors",
    features: [
      "Sole proprietorship / business name registration",
      "Renewal reminders & filing support",
      "3 lawyer letters or calls per year",
      "3 document reviews per year (up to 15 pages)",
      "Contract Library access",
      BILLING_SHORT,
    ],
  },
  "corporate-a": {
    name: "Corporate Package A — Business Formation",
    price: "$99.00",
    period: "/mo · 12-month term",
    description: "Business formation membership — from incorporation to an up-to-date minute book",
    features: [
      "Federal or Ontario incorporation",
      "Annual return filing & minute book upkeep",
      "Unlimited director, officer & address changes",
      "Shareholder agreement drafting",
      "10 lawyer letters or calls per year",
      "10 document reviews per year (up to 20 pages)",
      BILLING_SHORT,
    ],
  },
  "corporate-b": {
    name: "Corporate Package B — Procurement Law",
    price: "$499.00",
    period: "/mo · 12-month term",
    description: "Government contracting membership — RFPs, bids and public-sector contracts",
    features: [
      "RFP / bid response review",
      "Bid protests, appeals & debriefings",
      "Government contract negotiation & compliance review",
      "20 lawyer letters or calls per year",
      "20 document reviews per year (up to 25 pages)",
      BILLING_SHORT,
    ],
  },
  "corporate-c": {
    name: "Corporate Package C — Litigation & Disputes",
    price: "$999.00",
    period: "/mo · 12-month term",
    description: "Corporate litigation membership — disputes, claims and commercial matters",
    features: [
      "Commercial dispute assessment",
      "Contract breach & shareholder dispute support",
      "Mediation & settlement negotiation",
      "40 lawyer letters or calls per year",
      "40 document reviews per year (up to 25 pages)",
      "15 collection letters per month",
      BILLING_SHORT,
    ],
  },
  // Membership Bundles
  essential: {
    name: "Essential Bundle",
    price: "$4.99",
    period: "/mo · 12-month term",
    description: "Discounts on core legal services — yearly membership",
    features: [
      "Notary: $10 member fee per document",
      "Simple will: $100 member fee",
      "Ontario small claims pre-trial package: $999 member fee",
      "Agreed separation / marriage contract: $999 member fee",
      "15% courtesy discount on participating referral partners’ own fees",
      "Email support",
      BILLING_SHORT,
    ],
  },
  starter: {
    name: "Starter Bundle",
    price: "$6.99",
    period: "/mo · 12-month term",
    description: "Essential legal tools — yearly membership",
    features: [
      "Everything in Essential, plus:",
      "1 case-law research report per month",
      "1 contract download per month (PDF or Word)",
      "e-Notary: $0 member fee",
      BILLING_SHORT,
    ],
  },

  professional: {
    name: "Professional Bundle",
    price: "$9.99",
    period: "/mo · 12-month term",
    description: "Member services and tools — yearly membership",
    features: [
      "Everything in Starter, plus:",
      `${PROFESSIONAL_REPORTS_PER_MONTH} case-law research reports per month`,
      "5 contract downloads per month (Word & PDF)",
      "In-person and e-Notary: $0 member fee",
      "Simple will: $0 member fee",
      BILLING_SHORT,
    ],
  },
  business: {
    name: "Executive Bundle",
    price: "$14.99",
    period: "/mo · 12-month term",
    description: "Complete legal toolkit — yearly membership",
    features: [
      "Everything in Professional, plus:",
      "5 case-law research reports per month",
      "Unlimited contract downloads (Word & PDF), fair use",
      "In-person and e-Notary: $0 member fee",
      "Simple will: $0 member fee",
      "Complex wills: 50% off quoted fee",
      "Demand letters: $0 member fee, up to 3/year",
      BILLING_SHORT,
    ],
  },
};

type PlanKey = keyof typeof plans;

// The Contract Library subscription is billed per month; Case Law Research packs are one-time purchases
// with no 12-month term, so checkout must not show them the membership note.
const MONTH_TO_MONTH: PlanKey[] = ["contracts"];

const Checkout = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const bundleKey = searchParams.get("bundle");
  const planParam = searchParams.get("plan");
  const langParam = searchParams.get("lang");
  const requestedKey = bundleKey || planParam || "contracts";
  const selectedKey = (requestedKey === "executive" ? "business" : requestedKey) as PlanKey;
  const basePlan = plans[selectedKey] || plans.contracts;
  const plan =
    selectedKey === "contracts" && langParam === "fr"
      ? {
          ...basePlan,
          name: "Contract Library — Français (French)",
          price: "$5.99",
          features: [...basePlan.features, "French-language templates (+$1/mo)"],
        }
      : basePlan;
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState({
    cardNumber: "",
    expiry: "",
    cvc: "",
    name: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to complete your subscription.",
        variant: "destructive",
      });
      navigate("/login?redirect=/checkout?" + (bundleKey ? "bundle=" + bundleKey : "plan=" + planParam));
      return;
    }

    setIsProcessing(true);
    
    setIsProcessing(false);
    toast({title: "Online activation unavailable", description: "Please contact LegalXpress to arrange membership payment."});
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || "";
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(" ") : value;
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (v.length >= 2) {
      return v.substring(0, 2) + "/" + v.substring(2, 4);
    }
    return v;
  };

  return (
    <Layout>
      <div className="pt-32 pb-20 min-h-screen bg-gradient-to-b from-background to-muted/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <div className="mb-8">
            <h1 className="font-display text-3xl md:text-4xl text-foreground mb-2">Complete your membership</h1>
            <p className="text-muted-foreground">{plan.name}</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {/* Order Summary */}
            <Card className="h-fit">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="h-5 w-5 text-secondary" />
                  <CardTitle className="font-display">{plan.name}</CardTitle>
                </div>
                <CardDescription className="font-body">
                  {plan.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-baseline gap-1">
                  <span className="font-display text-4xl font-bold text-foreground">
                    {plan.price}
                  </span>
                  <span className="text-muted-foreground font-body">
                    {plan.period}
                  </span>
                </div>

                <Separator />

                <ul className="space-y-3">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
                      <span className="text-sm font-body text-muted-foreground">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>

                <Separator /><PriceNotice /><div className="flex justify-between items-center">
                  <span className="font-body text-muted-foreground">Monthly subscription fee (HST extra)</span>
                  <span className="font-display text-xl font-bold">{plan.price}</span>
                </div>

                {plan.period.includes("/mo") && !MONTH_TO_MONTH.includes(selectedKey) && (
                  <p className="text-xs text-center text-muted-foreground font-body">{BILLING_NOTE}</p>
                )}
              </CardContent>
            </Card>

            {/* Payment Form */}
            <Card>
              <CardHeader>
                <CardTitle className="font-display flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment Details
                </CardTitle>
                <CardDescription className="font-body">Online payment activation is not available on this page. Please book a consultation to confirm your membership and payment arrangements. Do not enter payment card details.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4"><fieldset disabled className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Cardholder Name</Label>
                    <Input
                      id="name"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input
                      id="cardNumber"
                      placeholder="4242 4242 4242 4242"
                      value={formData.cardNumber}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          cardNumber: formatCardNumber(e.target.value),
                        })
                      }
                      maxLength={19}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiry">Expiry Date</Label>
                      <Input
                        id="expiry"
                        placeholder="MM/YY"
                        value={formData.expiry}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            expiry: formatExpiry(e.target.value),
                          })
                        }
                        maxLength={5}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cvc">CVC</Label>
                      <Input
                        id="cvc"
                        placeholder="123"
                        value={formData.cvc}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            cvc: e.target.value.replace(/\D/g, "").slice(0, 4),
                          })
                        }
                        maxLength={4}
                        required
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground"
                    size="lg"
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      "Processing..."
                    ) : (
                      <>
                        <Lock className="mr-2 h-4 w-4" />
                        Subscribe Now
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-center text-muted-foreground font-body">
                    <Lock className="inline h-3 w-3 mr-1" />
                    Payment form unavailable — no payment or subscription is processed here
                  </p>
                </fieldset></form>
              </CardContent>
            </Card>
          </div>
          {selectedKey !== "contracts" && <LegalDisclaimer context="membership" className="mt-8" />}
        </div>
      </div>
    </Layout>
  );
};

export default Checkout;
